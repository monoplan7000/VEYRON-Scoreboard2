# VEYRON Halloween Scoreboard v1.1

FIXED E000: rendered height 112px instead of 220px; ascent 10px instead of 200px. This places the top near the scoreboard TITLE baseline and the rest below it.

TAB config.yml scoreboard example:

```yaml
scoreboard:
  enabled: true
  toggle-command: /sb
  remember-toggle-choice: false
  hidden-by-default: false
  delay-on-join-milliseconds: 0
  scoreboards:
    halloween:
      title: "\uE000"
      lines:
        - " "
        - "  "
        - "   "
        - "    "
        - "     "
        - "      "
        - "       "
        - "        "
        - "         "
        - "          "
        - "           "
        - "            "
```

NOTE: blank lines provide sidebar height; TAB may trim them depending on version. Vanilla scoreboards cannot truly layer a full frame behind lines; alignment may require further tuning.

Upload ZIP to a NEW GitHub release v1.1, change resource-pack URL, update SHA-1, restart server.

Other glyph mappings unchanged.
